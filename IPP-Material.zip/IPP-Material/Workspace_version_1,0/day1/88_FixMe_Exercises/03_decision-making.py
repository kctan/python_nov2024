person = 23

if person >= 21:
    print ("This person is an adult")
else:
    print ("This person is a minor")



vip = "Jack"

if vip == "Jack":
    print ("Welcome, CEO")
elif vip == "Mary":
    print ("Welcome, CFO")
else:
    print ("Unrecognised person")
