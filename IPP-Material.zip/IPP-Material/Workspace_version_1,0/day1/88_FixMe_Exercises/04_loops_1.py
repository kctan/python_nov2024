numbers = [4, 2, 6, 10]
for num in numbers:
    print(num)


#"Hello world" will be printed 5 times
'''
i = 1
total = 0
while i < 11:
    print("number", i)
    total = total + i
    i = i + 1
    

print("total:", total)
'''