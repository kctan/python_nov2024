centimeter = 350
meter = centimeter / 100
#print(meter)

print (str(centimeter) + " centimeter in meter is: " + str(meter) + " meter.")