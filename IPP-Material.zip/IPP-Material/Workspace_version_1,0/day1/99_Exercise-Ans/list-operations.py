aList = [1, -5, 15]

aList.append(20)

aList.remove(15)

total = aList[0] + aList[1] + aList[2]
print("Total is " + str(total))

# Alternate solution using built-in function
#total = sum(aList)
#print("Total is " + str(total))
