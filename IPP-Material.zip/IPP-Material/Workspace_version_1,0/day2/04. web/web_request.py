import requests

url="https://api.data.gov.sg/v1/environment/24-hour-weather-forecast?date=2023-01-03"
req=requests.get(url)
print(req.text)

