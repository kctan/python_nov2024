## REMEMBER to perform a pip install pywin32 first.

import win32com.client

outlook = win32com.client.Dispatch('outlook.application')
mail = outlook.CreateItem(0)
mail.To = 'tan_kok_cheng@rp.edu.sg'
mail.Subject = 'Demo Email  30 Nov 2024'
mail.HTMLBody = '<h3>This is an email sent from Outlook client on 30 Nov 2024...</h3>'
mail.Body = "This is the normal body"
#mail.Attachments.Add('c:\\sample.xlsx')
#mail.Attachments.Add('c:\\sample2.xlsx')
#mail.CC = 'somebody@company.com'
mail.Send()
print("Sent")